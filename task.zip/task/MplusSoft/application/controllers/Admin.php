<?php
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
defined('BASEPATH') OR exit('?No direct script access allowed');

class Admin extends CI_Controller
{
  public function __construct()
  {
    parent:: __construct();
    $this->load->model('Admin_model');
	$this->load->helper('url');
	$this->load->library('session');
  }
  //admin login 
  public function index()
  {
    $this->load->view('admin/admin_login');
  }
  //users data
  public function Users()
  {
	$user_data = $this->Admin_model->get_user_data();
    $this->load->view('admin/user_list',['user_data'=>$user_data]);
  }
  //destroy session on admin  logout
  public function Logout()
  {
	  $this->session->unset_userdata($user_id);
	  $this->load->view('admin/admin_login');
  }
  //check admin login
  public function check_login()
  {
	  $username = $this->input->post('username');
	  $password = md5($this->input->post('user_password'));
	  
	  $check = $this->Admin_model->login_check($username,$password);
	  //print_r($check);
	  if(!empty($check))
			{
				//echo "hii";
				$user_id  = $check[0]['user_id '];
				$user_email  = $check[0]['user_email '];
				$this->session->set_userdata('user_id', $user_id);
				$this->session->set_userdata('user_email', $user_email);
				
				
				$data = array(
					'user_email' => $check[0]['user_email'],
					'user_id' => $check[0]['user_id']
				);	

				$this->session->set_userdata($data);
				
				//$this->Users();	
				//$user_data = $this->Admin_model->get_user_data();
				//print_r($user_data);exit();
				//$this->load->view('admin/user_list',['user_data'=>$user_data]);
				redirect(base_url().'Admin/Users',refresh);
			}else{
				$this->load->view('admin/admin_login',['toastr'=>2]);
			}
  }
  
  public function get_user_details_by_id()
  {
	  $user_data = $this->Admin_model->get_user_data_by_id($_POST['user_id']);
	  //print_r($user_data);
	  echo json_encode($user_data);
  }
  //update users data
  public function edit_user_datas()
	{
	    //print_r($_POST);
	    $price = $_POST['edit_price'];
	    $discount = $_POST['edit_discount'];
	    $var = $discount/100;
	    $total_discount = $var*$price;
	    $sell_price = $price - $total_discount;
	    
	    if(isset($_FILES['edit_image_file']) && !empty($_FILES['edit_image_file']['name']))
            {
                $config['upload_path']          = './profile_images/';
                $config['allowed_types']        = 'gif|jpg|png';
                //$config['max_size']             = 100;
                //$config['max_width']            = 1024;
                //$config['max_height']           = 768;
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('edit_image_file'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        echo "error";

                       // $this->load->view('upload_form', $error);
                }
                else
                {
                        $data = $this->upload->data();
                        //$image = $data['file_name'];
                        //print_r($image);
                        $updated_data=array('user_profile_image'=>$data['file_name'],
											'user_first_name'=>$_POST['editf_name'],
											'user_last_name	'=>$_POST['editl_name'],
											'user_email'=>$_POST['edit_email'],
											'user_city'=>$_POST['edit_city'],
											'user_address'=>$_POST['edit_add'],
											'user_mod_date'=>date("Y-m-d H:i:s"));
						
                        $result = $this->Admin_model->update_user_data($_POST['edit_id'],$updated_data);
                        if($updated_data)
                        {
                            echo "1";
                        }
                }
            }else{
                $updated_data=array('user_first_name'=>$_POST['editf_name'],
											'user_last_name	'=>$_POST['editl_name'],
											'user_email'=>$_POST['edit_email'],
											'user_city'=>$_POST['edit_city'],
											'user_address'=>$_POST['edit_add'],
											'user_mod_date'=>date("Y-m-d H:i:s"));
						
                        $result = $this->Admin_model->update_user_data($_POST['edit_id'],$updated_data);
                        if($updated_data)
                        {
                            echo "1";
                        }
            }
	}
	
	//inactive user
	public function delete_user_data()
	{
		$data = array('user_status'=>'Inactive');
		$deleted_data = $this->Admin_model->delete_user($_POST['delete_id'],$data);
	    if($deleted_data)
        {
            echo "1";
        } 
	}
  
  
  
}