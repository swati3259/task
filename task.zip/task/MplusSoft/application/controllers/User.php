<?php
error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
defined('BASEPATH') OR exit('?No direct script access allowed');

class User extends CI_Controller
{
  public function __construct()
  {
    parent:: __construct();
    //$this->load->model('Vendor_model');
  }
  public function index()
  {
    $this->load->view('register_user');
  }
  //Insert user 
  public function add_user()
  {
	  //print_r($_POST);
	 
		
			if(isset($_FILES['profile_img']) && !empty($_FILES['profile_img']['name']))
            {
                $config['upload_path']          = './profile_images/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('profile_img'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        echo "error to upload image";

                       // $this->load->view('upload_form', $error);
                }
                else
                {
                        $data = $this->upload->data();
                        //$image = $data['file_name'];
                        //print_r($image);
                        
                            $data = array('user_profile_image' =>$data['file_name'],
    			              'user_first_name'=>$_POST['first_name'],
    			              'user_last_name'=>$_POST['last_name'],
    			              'user_email'=>$_POST['email'],
    						  'user_password'=>md5($_POST['password_confirmation']),
    						  'user_designation' =>$_POST['designation'],
    						  'user_city'=>$_POST['city'],
    						  'user_address'=> $_POST['address'],
    						  'user_status' =>'Active',
							  'user_crt_date'=>date("Y-m-d H:i:s")
    						  );
                        
				$this->load->database();
								$insert = $this->db->insert('tbl_users',$data);
								$insert_id = $this->db->insert_id();
								echo "<script>alert('User Data Inserted Successfully.')</script>";
								redirect(base_url().'User',refresh);
                }
        	} 
  }
  
  
  
  
  
}