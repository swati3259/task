<?php
class Admin_model extends CI_Model
{
	function __construct() 
	{
		parent::__construct();
		$this->load->database();
	}
	public function login_check($username,$password)
	{
		$this->db->select();
		$this->db->from('tbl_users');
		$this->db->where('user_email',$username);
		$this->db->where('user_password',$password);
		$this->db->where('user_designation','Admin');
		$query=$this->db->get();
		//echo $this->db->last_query();
		$res = $query->result_array();
		

		//$query = $this->db->get();

			if ( $query->num_rows() > 0 )
			{
					return $query->result_array();
			}else{
				 return false;
			}
	}
	
	public function get_user_data()
	{
		$this->db->select();
		$this->db->from('tbl_users');
		$this->db->where('user_designation','User');
		$this->db->where('user_status','Active');
		$query=$this->db->get();
		echo $this->db->last_query();
		$res = $query->result_array();
		

		//$query = $this->db->get();

			if ( $query->num_rows() > 0 )
			{
					return $query->result_array();
			}else{
				 return false;
			}
	}
	
	public function get_user_data_by_id($id)
	{
		$this->db->select();
		$this->db->from('tbl_users');
		$this->db->where('user_id',$id);
		$query=$this->db->get();
		//echo $this->db->last_query();
		$res = $query->result_array();
		

		//$query = $this->db->get();

			if ( $query->num_rows() > 0 )
			{
					return $query->result_array();
			}else{
				 return false;
			}
	}
	public function update_user_data($id,$data)
	{
		$this->db->where('user_id', $id);
			$this->db->update('tbl_users',$data);
			return true;
	}
	public function delete_user($id,$data){
		$this->db->where('user_id', $id);
			$this->db->update('tbl_users',$data);
			return true;
	}
}
?>







