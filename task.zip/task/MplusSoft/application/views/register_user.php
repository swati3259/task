<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
	.error{
		color : red;
	}
</style>

<div class="container" style="margin-top:30px">
<div class="col-md-10 col-md-offset-1">
    <div class="panel panel-default">
  <div class="panel-heading"><h3 class="panel-title"><strong>Resister User</strong></h3>
      <div style="float:right; font-size: 80%; position: relative; top:-10px"><a href="#">Forgot password?</a></div>
  </div>
  
  <div class="panel-body">
   <form role="form" action="<?php echo base_url();?>User/add_user" method="post" enctype="multipart/form-data" name="register_form">
   <!--<div class="alert alert-danger">
                <a class="close" data-dismiss="alert" href="#">×</a>Incorrect Username or Password!
            </div>-->
            <div class="row">
    			<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
                        <input type="text" name="first_name" id="first_name" class="form-control" placeholder="First Name" tabindex="1">
					</div>
				</div>
               
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
						<input type="text" name="last_name" id="last_name" class="form-control " placeholder="Last Name" tabindex="2">
					</div>
				</div>
			</div>
			<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-6">
			<div class="form-group">
				<textarea class="form-control " id="address" name="address" rows="4" cols="50"></textarea>
			</div>
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
						<input type="text" name="city" id="city" class="form-control " placeholder="City" tabindex="2">
					</div>
				</div>
			</div>
			<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-6">
			<div class="form-group">
				<input type="text" name="email" id="email" class="form-control " placeholder="Email Address" tabindex="4">
			</div>
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6">
					<select class="form-control" id="designation" name="designation">
						<option value=" ">Select Degination</option>
						<option value="Admin">Admin</option>
						<option value="User">User</option>
					  </select>
			</div>
			</div>
			
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
						<input type="password" name="password" id="password" class="form-control " placeholder="Password" tabindex="5">
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
						<input type="password" name="password_confirmation" id="password_confirmation" class="form-control " placeholder="Confirm Password">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6">
					<div class="form-group">
						<input type="file" name="profile_img" id="profile_img" class="form-control " >
					</div>
				</div>
				
			</div>
                                    
                                    <div class="input-group">
                                      <div class="checkbox" style="margin-top: 0px;">
                                        <label>
                                          <input id="login-remember" type="checkbox" name="remember" value="1"> Remember me
                                        </label>
                                      </div>
                                    </div>
                                    
  <button type="submit" class="btn btn-success">Sign in</button>
  
  <hr style="margin-top:10px;margin-bottom:10px;" >
  
  <div class="form-group">
                                    
                                        <div style="font-size:85%">
                                            Don't have an account! 
                                        <a href="#" onClick="$('#loginbox').hide(); $('#signupbox').show()">
                                            Sign Up Here
                                        </a>
                                        </div>
                                    
                                </div> 
</form>
  </div>
</div>
</div>
</div>
<!--validation-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<script src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/additional-methods.js"></script>

<script>
$(function() {
  
  $("form[name='register_form']").validate({
    
    rules: {
      first_name:{
		  required: true,
		  lettersonly: true
	  },
	  last_name:{
		  required: true,
		  lettersonly: true
	  },
	  email:{
		  required: true,
		  email: true
	  },
	  password:{
		  required: true,
		  minlength:6
	  },
	  password_confirmation:{
		  required: true,
		  equalTo: "#password",
		  minlength:6
	  },
	  designation:{
		  required: true
	  },
	  city:{
		  required: true
	  },
	  address:{
		  required: true
	  },
	  profile_img:{
		  required: true
	  }
      
    },
    // Specify validation error messages
    messages: {
      first_name: {
		  required: "Please Enter First Name",
		  lettersonly: "Enter Only Alphabets"
	  },
	  last_name:{
		  required: "Please Enter First Name",
		  lettersonly: "Enter Only Alphabets"
	  },
	  email:{
		  required: "Please Enter Email",
		  minlength : "Please Enter Valid Email"
	  },
	  password:{
		  required: "Please Enter Password",
		  minlength : "Enter at least 6 didits"
	  },
	  password_confirmation:{
		  required: "Please Enter Password",
		  equalTo:" Enter Confirm Password Same as Password",
		  minlength : "Enter at least 6 didits"
	  },
	  designation:{
		  required: "Please Select Degination"
	  },
	  city:{
		  required: "Please Enter City Name"
	  },
	  address:{
		  required: "Please Enter Address"
	  },
	  profile_img:{
		  required: "Please select Profile Image"
	  }
	  
      
    },
    submitHandler: function(form) {
      form.submit();
    }
    
  });
});
</script>

